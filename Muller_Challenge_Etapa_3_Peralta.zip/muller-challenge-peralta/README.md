# MÜLLER CHALLENGE — Etapa 3: Peralta

Entrega del módulo de programación y lógica matemática. Incluye un laboratorio independiente para probar la implementación mientras se recibe la interfaz general del equipo.

## Requisitos

- Visual Studio Code.
- Extensión **Live Server**.
- Navegador actualizado.
- Conexión a internet para cargar Bootstrap, Chart.js y MathJax desde CDN.

No requiere backend, base de datos, instalación de paquetes ni frameworks SPA.

## Cómo ejecutar

1. Descomprime el archivo ZIP.
2. Abre la carpeta `muller-challenge-peralta` en Visual Studio Code.
3. Abre `index.html`.
4. Haz clic derecho y selecciona **Open with Live Server**.
5. En el laboratorio puedes calcular todas las iteraciones, avanzar una por una, reiniciar o cargar los tres casos definidos en el documento del proyecto.
6. Para ejecutar las pruebas automatizadas, abre `tests/tests.html` con Live Server y pulsa **Ejecutar pruebas**.

## Funcionalidades implementadas

- Parser matemático seguro mediante tokenizer y parser recursivo. No utiliza `eval()` ni `Function()`.
- Operadores `+`, `-`, `*`, `/`, `^`, paréntesis y multiplicación implícita (`2x`, `3(x+1)`).
- Funciones `sin`, `cos`, `tan`, `exp`, `log`, `sqrt` y constantes `pi`, `e`.
- Aritmética compleja para que el discriminante y las aproximaciones puedan ser complejos.
- Diferencias divididas, coeficientes `a`, `b`, `c`, discriminante y selección del denominador de mayor módulo.
- Sesión paso a paso, desplazamiento de aproximaciones, error, residuo, convergencia y límite de iteraciones.
- Tabla de resultados, detalle de cada iteración y gráfica Chart.js de la parte real.
- Mensajes para expresiones inválidas, valores iniciales repetidos, división por cero, denominador inestable y otros errores matemáticos.
- Diseño responsive para escritorio y móvil.

## API pública para integración

Los scripts se cargan en este orden: `math-parser.js`, `muller.js`, `graph.js`.

### MathParser

- `MathParser.parse(expression)`: valida y convierte la expresión en estructura interna.
- `MathParser.compile(expression)`: devuelve una función que recibe `x` y devuelve `{ re, im }`.
- `MathParser.evaluate(expressionOrAst, x)`: evalúa una expresión o estructura ya analizada.
- `MathParser.complex`: operaciones complejas internas.

### MullerMethod

- `MullerMethod.createSession(options)`: crea una sesión paso a paso.
- `session.next()`: calcula una iteración y devuelve una copia del estado.
- `session.run()`: ejecuta hasta convergencia, error o máximo de iteraciones.
- `session.reset()`: vuelve a los tres valores iniciales.
- `session.snapshot()`: devuelve el estado actual.
- `MullerMethod.run(options)`: ejecuta el método completo en una sola llamada.
- `MullerMethod.calculateNext(fn, [x0,x1,x2])`: calcula una iteración sin crear sesión.
- `MullerMethod.formatComplex(value)`: convierte un complejo en texto.

Ejemplo:

```javascript
const session = MullerMethod.createSession({
  expression: "x^3-x-1",
  x0: 1,
  x1: 1.5,
  x2: 2,
  tolerance: 0.0001,
  maxIterations: 50
});
const estadoDespuesDeUnaIteracion = session.next();
const resultadoFinal = session.run();
console.log(resultadoFinal.rootText, resultadoFinal.status);
```

### Formato de resultado

El estado devuelto contiene:

- `status`: `ready`, `running`, `converged`, `max-iterations` o `error`.
- `message`: mensaje explicativo.
- `root`: objeto complejo `{ re, im }` o `null`.
- `rootText`: raíz formateada o `null`.
- `iterations`: cantidad de iteraciones calculadas.
- `rows`: historial de iteraciones.
- `points`: los tres puntos actuales.
- `converged`: booleano.

Cada fila contiene `iteration`, `x0`, `x1`, `x2`, `x3`, `fx3`, `error`, `residual`, `h0`, `h1`, `delta0`, `delta1`, `d`, `a`, `b`, `c`, `discriminant`, `denominator`, `values` y `text`. Los valores matemáticos se representan como complejos `{re, im}`; no asumir que siempre son reales.

## Cómo debe utilizarlo Said

Para el juego **Cazadores de Raíces**, Said debe llamar a `MullerMethod.createSession()` o `MullerMethod.run()` y reutilizar el resultado. No debe copiar ni reimplementar el algoritmo. Para validar una aproximación puede comprobar `result.converged`, `result.root` y evaluar el residuo con `MathParser.compile(expresion)(result.root)`. Si el juego necesita revelar pasos, puede consumir `session.next()` y mostrar cada fila de `snapshot().rows`.

## Casos de prueba del proyecto

| Función | x₀ | x₁ | x₂ | Raíz real esperada aprox. |
|---|---:|---:|---:|---:|
| `x^3-x-1` | 1 | 1.5 | 2 | 1.3247 |
| `x^2-2` | 0 | 1 | 2 | 1.4142 |
| `x^3+1` | -2 | -1.5 | -0.5 | -1.0000 |

### Verificación realizada en esta entrega

Se ejecutó el motor matemático en un entorno JavaScript local para comprobar los tres casos anteriores, la multiplicación implícita, la función trigonométrica y la raíz compleja `sqrt(-4)`. Los tres casos convergieron con los valores iniciales del documento. La página `tests/tests.html` contiene además las pruebas para repetir la verificación desde el navegador. La gráfica y la interfaz deben probarse en el navegador con Live Server, ya que dependen de Chart.js y del DOM.

## Integración posterior con la interfaz de Danilo

Esta entrega usa una interfaz independiente para que el módulo pueda demostrarse antes de recibir los archivos de Danilo. Al integrarlo, se conservan `js/math-parser.js`, `js/muller.js` y `js/graph.js`; se conectan los campos y botones de su HTML con las funciones públicas descritas arriba. Evitar reemplazar su diseño o duplicar el algoritmo. `graph.js` necesita Chart.js cargado antes de invocar `MullerGraph.draw()`.

## Archivos

```text
muller-challenge-peralta/
├── index.html
├── README.md
├── css/
│   ├── styles.css
│   ├── animations.css
│   └── responsive.css
├── js/
│   ├── app.js
│   ├── math-parser.js
│   ├── muller.js
│   └── graph.js
└── tests/
    ├── tests.html
    └── muller-tests.js
```
