/* Inicialización de la interfaz del laboratorio. No contiene el algoritmo matemático. */
(function () {
  "use strict";
  const $ = id => document.getElementById(id);
  if (window.lucide) window.lucide.createIcons();
  let session = null;
  const examples = {
    one: { expression:"x^3-x-1", x0:1, x1:1.5, x2:2, tolerance:0.0001, maxIterations:50 },
    two: { expression:"x^2-2", x0:0, x1:1, x2:2, tolerance:0.0001, maxIterations:50 },
    three: { expression:"x^3+1", x0:-2, x1:-1.5, x2:-0.5, tolerance:0.0001, maxIterations:50 }
  };
  const format = z => MullerMethod.formatComplex(z);
  const number = n => Number(n).toExponential(4);
  function readConfig() {
    const config = { expression:$('expression').value.trim(), x0:Number($('x0').value), x1:Number($('x1').value), x2:Number($('x2').value), tolerance:Number($('tolerance').value), maxIterations:Number($('maxIterations').value) };
    if (!config.expression) throw new Error('Escribe una función matemática.');
    ['x0','x1','x2','tolerance','maxIterations'].forEach(key => { if (!Number.isFinite(config[key])) throw new Error('Revisa el valor de '+key+'.'); });
    if (!(config.tolerance > 0)) throw new Error('La tolerancia debe ser mayor que cero.');
    if (!Number.isInteger(config.maxIterations) || config.maxIterations < 1 || config.maxIterations > 500) throw new Error('El máximo de iteraciones debe ser un entero entre 1 y 500.');
    return config;
  }
  function showMessage(text, type) { const el=$('message'); el.textContent=text; el.className='message '+(type||'info'); }
  function setMetrics(snapshot) {
    const labels={ready:'Pendiente',running:'En proceso',converged:'Convergió', 'max-iterations':'Límite alcanzado',error:'Error'};
    $('metricStatus').textContent=labels[snapshot.status]||snapshot.status;
    $('metricStatusNote').textContent=snapshot.message;
    $('metricIterations').textContent=snapshot.iterations;
    const last=snapshot.rows[snapshot.rows.length-1];
    $('metricRoot').textContent=last?format(last.x3):'—';
    $('metricError').textContent=last?number(last.error):'—';
  }
  function renderDetails(row) {
    if (!row) { $('iterationDetails').className='details-empty'; $('iterationDetails').textContent='Los cálculos intermedios aparecerán aquí al ejecutar el método.'; return; }
    const fields=[['h₀',row.h0],['h₁',row.h1],['δ₀',row.delta0],['δ₁',row.delta1],['d = a',row.a],['b',row.b],['c',row.c],['Discriminante',row.discriminant],['Denominador elegido',row.denominator],['x₃',row.x3],['f(x₃)',row.fx3],['Error',row.error]];
    $('iterationDetails').className='';
    $('iterationDetails').innerHTML='<div class="detail-list">'+fields.map(([label,value])=>'<div class="detail-item"><span>'+label+'</span><b>'+format(value)+'</b></div>').join('')+'</div><p class="detail-note">Se seleccionó el denominador con mayor módulo entre b + √Δ y b − √Δ. Después, los puntos se desplazan: x₀ ← x₁, x₁ ← x₂ y x₂ ← x₃.</p>';
  }
  function renderTable(rows) {
    $('rowCount').textContent=rows.length+' REGISTROS';
    $('resultsBody').innerHTML=rows.length?rows.map(r=>'<tr><td>'+r.iteration+'</td><td>'+format(r.x0)+'</td><td>'+format(r.x1)+'</td><td>'+format(r.x2)+'</td><td>'+format(r.x3)+'</td><td>'+format(r.fx3)+'</td><td>'+number(r.error)+'</td></tr>').join(''):'<tr><td colspan="7" class="empty-row">Aún no hay resultados. Ejecuta el cálculo para llenar la tabla.</td></tr>';
  }
  function render(snapshot) {
    setMetrics(snapshot); renderTable(snapshot.rows); renderDetails(snapshot.rows[snapshot.rows.length-1]);
    try {
      const last=snapshot.rows[snapshot.rows.length-1];
      const realPoints=[...snapshot.points.map(p=>p.re),...(last?[last.x3.re]:[])].filter(Number.isFinite);
      const low=Math.min(-5,...realPoints)-1, high=Math.max(5,...realPoints)+1;
      MullerGraph.draw('functionChart',$('expression').value,snapshot,{min:low,max:high});
    } catch (error) { showMessage(error.message,'error'); }
  }
  function create() { session=MullerMethod.createSession(readConfig()); return session; }
  function advance() {
    try {
      if (!session) create();
      const result=session.next(); render(result);
      if(result.status==='converged') showMessage('¡Convergencia alcanzada! '+(result.rootText||''),'success');
      else if(result.status==='error') showMessage(result.message,'error');
      else if(result.status==='max-iterations') showMessage(result.message,'error');
      else showMessage('Iteración '+result.iterations+' calculada correctamente. Puedes continuar.','info');
    } catch(error) { showMessage(error.message,'error'); }
  }
  $('calculateBtn').addEventListener('click',()=>{
    try { create(); const result=session.run(); render(result); showMessage(result.message+(result.rootText?' Raíz aproximada: '+result.rootText:''),result.converged?'success':(result.status==='error'?'error':'info')); }
    catch(error){session=null;showMessage(error.message,'error');}
  });
  $('nextBtn').addEventListener('click',advance);
  $('resetBtn').addEventListener('click',()=>{try{if(session){render(session.reset());}else{session=null;render({status:'ready',message:'Cálculo reiniciado.',iterations:0,rows:[],points:[],converged:false});}showMessage('Cálculo reiniciado.','info');}catch(e){showMessage(e.message,'error');}});
  $('loadExampleBtn').addEventListener('click',()=>{const ex=examples[$('exampleSelect').value];Object.keys(ex).forEach(k=>$(k).value=ex[k]);session=null;render({status:'ready',message:'Ejemplo cargado.',iterations:0,rows:[],points:[{re:ex.x0,im:0},{re:ex.x1,im:0},{re:ex.x2,im:0}],converged:false});showMessage('Ejemplo cargado. Presiona “Calcular todo” o “Siguiente iteración”.','info');});
  $('runTestsBtn').addEventListener('click',()=>{
    const tests=[
      {name:'Caso 1 · x³ − x − 1',options:examples.one,expected:1.324717957},
      {name:'Caso 2 · x² − 2',options:examples.two,expected:Math.sqrt(2)},
      {name:'Caso 3 · x³ + 1',options:examples.three,expected:-1}
    ];
    const results=tests.map(t=>{try{const r=MullerMethod.run(t.options);const ok=r.converged&&Math.abs(r.root.im)<1e-7&&Math.abs(r.root.re-t.expected)<1e-3;return {name:t.name,ok,detail:ok?'Raíz '+format(r.root)+' · '+r.iterations+' iteraciones':r.message+' · resultado '+(r.rootText||'sin raíz')};}catch(e){return {name:t.name,ok:false,detail:e.message};}});
    $('testResults').innerHTML=results.map(r=>'<div class="test-item '+(r.ok?'pass':'fail')+'"><span>'+r.name+'<br><small>'+r.detail+'</small></span><b>'+(r.ok?'APROBADA':'REVISAR')+'</b></div>').join('');
  });
  render({status:'ready',message:'Listo para calcular.',iterations:0,rows:[],points:[{re:1,im:0},{re:1.5,im:0},{re:2,im:0}],converged:false});
})();
