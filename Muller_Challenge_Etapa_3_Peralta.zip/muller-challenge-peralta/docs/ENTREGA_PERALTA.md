# Entrega técnica — Integrante 3: Peralta

## Alcance
Se desarrolló el motor matemático y un laboratorio independiente para comprobarlo. No se desarrollaron juegos, desafíos ni evaluación final, porque corresponden a la etapa de Said. La integración visual definitiva queda pendiente de recibir la estructura HTML/CSS de Danilo.

## Decisiones técnicas
- JavaScript ES6 sin frameworks SPA.
- Parser seguro sin evaluación dinámica de código.
- Representación compleja `{re, im}` para conservar resultados complejos.
- Selección del denominador de mayor módulo en la fórmula de Müller.
- Criterio de convergencia por error escalado o residuo de la función.
- Chart.js representa la curva real y las aproximaciones que pertenecen al plano real.

## Resultados verificados
- `x^3-x-1`, (1, 1.5, 2): converge a aproximadamente 1.3247182939 en 3 iteraciones.
- `x^2-2`, (0, 1, 2): converge a aproximadamente 1.41421356237 en 1 iteración.
- `x^3+1`, (-2, -1.5, -0.5): converge a aproximadamente -0.999999870746 en 8 iteraciones.

También se verificó `2x+3(x+1)` en x=2, `sin(pi/2)` y `sqrt(-4)`.

## Limitación de la gráfica
La gráfica es un plano real x-f(x). Los cálculos complejos se conservan en el motor y la tabla, pero no se dibujan como puntos de una gráfica compleja, ya que esa sería una visualización diferente.

## Pendiente para integración grupal
Recibir la interfaz de Danilo, conectar los elementos existentes sin rehacer el diseño y coordinar con Said el consumo de la API pública.
