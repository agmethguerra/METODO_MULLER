# MÜLLER CHALLENGE · Etapa 1 · Valery
## Investigación académica, verificación de fórmulas y paquete de transferencia para Danilo

---

# PARTE A. INVESTIGACIÓN ACADÉMICA

## A.1 Origen del método
El método fue publicado por **David E. Muller** en 1956 (*A method for solving algebraic equations using an automatic computer*, Mathematical Tables and Other Aids to Computation, vol. 10, n.º 56, pp. 208–215). Se concibió para calcular por computadora las raíces de ecuaciones algebraicas, incluidas las complejas.

Su idea es una generalización del **método de la secante**: la secante sustituye la función por una recta que pasa por dos puntos; Müller la sustituye por una **parábola que pasa por tres puntos** y toma una raíz de esa parábola como nueva aproximación.

> Nota de verificación: la referencia de 1956 está citada de memoria y no pude consultar fuentes externas desde este entorno. Confirmar volumen y páginas en la bibliografía de la asignatura antes de ponerla en la diapositiva.

## A.2 Fundamento matemático (resumen)
1. Se dan tres puntos distintos \(x_0,x_1,x_2\) y se evalúa \(f\) en ellos.
2. Se construye el polinomio cuadrático centrado en \(x_2\):  \(p(x)=a(x-x_2)^2+b(x-x_2)+c\), con \(p(x_i)=f(x_i)\), \(i=0,1,2\).
3. Con \(h_0=x_1-x_0\), \(h_1=x_2-x_1\), \(\delta_0=\frac{f(x_1)-f(x_0)}{h_0}\), \(\delta_1=\frac{f(x_2)-f(x_1)}{h_1}\):
   \(a=d=\frac{\delta_1-\delta_0}{h_1+h_0}\), \(b=\delta_1+h_1d\), \(c=f(x_2)\).
4. Se resuelve \(p(x_3)=0\). La fórmula cuadrática racionalizada es \(x_3=x_2-\frac{2c}{b\pm\sqrt{b^2-4ac}}\).
5. Se elige el signo que hace **mayor** el módulo del denominador. Así se evita la cancelación numérica y se escoge la raíz de la parábola más cercana a \(x_2\).
6. Se calcula \(E=|x_3-x_2|\); si \(E<\text{tol}\) se detiene; si no, \((x_0,x_1,x_2)\leftarrow(x_1,x_2,x_3)\).

## A.3 Utilidad en ecuaciones no lineales
- Raíces de ecuaciones trascendentes y algebraicas sin solución cerrada.
- Raíces **complejas** de polinomios con datos de partida reales.
- Problemas donde \(f'\) no está disponible o es costosa.
- Aplicaciones típicas: ingeniería (ecuaciones características, vibraciones, circuitos), cálculo de ceros de polinomios y como componente de algoritmos de búsqueda de raíces polinómicas.

## A.4 Ventajas y limitaciones
**Ventajas:** orden ≈ 1.84; no usa derivada; una evaluación de \(f\) por iteración; encuentra raíces reales y complejas; contiene a la secante como caso límite (\(a\to0\)).

**Limitaciones:** convergencia no garantizada; dependencia de los tres puntos iniciales; requiere aritmética compleja; falla con puntos repetidos o \(h_0+h_1=0\); más lento en raíces múltiples; más laborioso de implementar.

## A.5 Comparación con bisección y Newton-Raphson

| Aspecto | Bisección | Newton-Raphson | Müller |
|---|---|---|---|
| Datos iniciales | Intervalo con cambio de signo | 1 punto | 3 puntos |
| Derivada | No | Sí | No |
| Orden de convergencia | 1 | 2 | ≈ 1.84 |
| Convergencia garantizada | Sí (continua + cambio de signo) | No | No |
| Evaluaciones por iteración | 1 | 2 (\(f\) y \(f'\)) | 1 |
| Raíces complejas con datos reales | No | No | Sí |

**Orden de Müller:** es la raíz real de \(t^3=t^2+t+1\), \(t\approx1.8393\). Para la secante, \(t^2=t+1\), \(t\approx1.618\).

## A.6 Interpolación cuadrática
Tres puntos con abscisas distintas determinan un único polinomio de grado ≤ 2 (unicidad de la interpolación polinómica). La forma de Newton centrada en \(x_2\) produce los coeficientes con las diferencias divididas \(\delta_0,\delta_1,d\), lo que evita resolver un sistema 3×3.

## A.7 Bibliografía sugerida (verificar edición disponible)
- Muller, D. E. (1956). *A method for solving algebraic equations using an automatic computer*. Mathematical Tables and Other Aids to Computation, 10(56), 208–215.
- Burden, R. L. & Faires, J. D. *Numerical Analysis* (apartado «Zeros of Polynomials and Müller's Method»).
- Chapra, S. C. & Canale, R. P. *Métodos numéricos para ingenieros* (capítulo de raíces de polinomios, método de Müller).

---

# PARTE B. VERIFICACIÓN MATEMÁTICA DE LAS FÓRMULAS

## B.1 Verificación algebraica de \(a\), \(b\), \(c\)
Con \(z=x-x_2\) y \(p(z)=az^2+bz+c\):

| Condición | Desarrollo | Resultado |
|---|---|---|
| \(p(x_2)=f(x_2)\) | \(z=0\) | \(c=f(x_2)\) ✔ |
| \(p(x_1)=f(x_1)\) | \(z=-h_1\): \(ah_1^2-bh_1+c=f(x_1)\); como \(f(x_1)=c-h_1\delta_1\) → \(-bh_1+ah_1^2=-h_1\delta_1\) | \(b=\delta_1+ah_1\) ✔ |
| \(p(x_0)=f(x_0)\) | \(z=-(h_0+h_1)\); como \(f(x_0)=c-h_1\delta_1-h_0\delta_0\), sustituyendo \(b\): \(a(h_0+h_1)h_0=h_0(\delta_1-\delta_0)\) | \(a=\frac{\delta_1-\delta_0}{h_0+h_1}=d\) ✔ |

Por tanto \(b=\delta_1+h_1d\), exactamente la fórmula del enunciado del proyecto.

## B.2 Verificación de la raíz racionalizada
\(az^2+bz+c=0\Rightarrow z=\frac{-b\pm\sqrt D}{2a}\). Multiplicando numerador y denominador por \(-b\mp\sqrt D\): \(z=\frac{b^2-D}{2a(-b\mp\sqrt D)}=\frac{4ac}{2a(-b\mp\sqrt D)}=\frac{-2c}{b\pm\sqrt D}\) ✔. Si \(a\to0\): \(z\to-c/b\) (paso de la secante) ✔.

## B.3 Verificación numérica
Todas las iteraciones del módulo 5 y los valores de los juegos se calcularon ejecutando el algoritmo completo en doble precisión (con aritmética compleja) y se contrastaron a mano en la iteración 1. Todos los valores concuerdan.

---

# PARTE C. EJEMPLO RESUELTO (resumen de referencia)

\(f(x)=x^3-x-1\), \(x_0=1,\ x_1=1.5,\ x_2=2\), tol \(=10^{-4}\), máx. 50. Error \(E=|x_3-x_2|\).

| Iter. | x₀ | x₁ | x₂ | x₃ | f(x₃) | Error |
|---|---|---|---|---|---|---|
| 1 | 1 | 1.5 | 2 | 1.333333 | 0.037037 | 0.666667 |
| 2 | 1.5 | 2 | 1.333333 | 1.324472 | −0.001051 | 0.008862 |
| 3 | 2 | 1.333333 | 1.324472 | 1.324718 | 1.436×10⁻⁶ | 2.468×10⁻⁴ |
| 4 | 1.333333 | 1.324472 | 1.324718 | **1.3247179572** | 7.15×10⁻¹³ | **3.37×10⁻⁷** |

Converge en **4 iteraciones** a 1.3247. El desarrollo completo con todos los coeficientes está en el módulo 5 del archivo HTML.

## Vectores de prueba para Peralta (referencia académica)

| Caso | Datos | Resultado esperado |
|---|---|---|
| Ejemplo base | \(x^3-x-1\), (1, 1.5, 2) | x₃(1) = 1.333333; raíz 1.3247179572 en 4 iteraciones |
| Nivel 2 | \(x^2-2\), (0, 1, 2) | x₃(1) = 1.414214; raíz √2 en 2 iteraciones (la 2.ª solo confirma, error ≈ 10⁻¹⁶) |
| Nivel 3 | \(x^3+1\), (−2, −1.5, −0.5) | x₃(1) = −0.116739; raíz −1 en 9 iteraciones |
| Raíz compleja | \(x^2+1\), (0, 1, 2) | D = −4; x₃(1) = i (los dos denominadores tienen igual módulo → convención: usar \(b+\sqrt D\)) |
| Error esperado | puntos repetidos (p. ej. x₀ = x₁) | h₀ = 0 → mensaje de error, sin NaN |

---

# PARTE D. INSTRUCCIONES MATHJAX PARA DANILO

1. En `index.html`, **antes** de cargar MathJax, declarar la configuración y luego el script:
```html
<script>
  window.MathJax = {
    tex: { inlineMath: [['\\(', '\\)']], displayMath: [['\\[', '\\]']] },
    options: { skipHtmlTags: ['script','noscript','style','textarea','pre','code'] }
  };
</script>
<script async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
```
2. Fórmulas en línea: `\( x_3 = x_2 - \frac{2c}{b \pm \sqrt{D}} \)`. Fórmulas en bloque: `\[ ... \]`.
3. En el texto HTML normal, escribir `&lt;` en lugar de `<` (por ejemplo, `D &lt; 0`). Dentro de una fórmula `\( ... \)` o `\[ ... \]` usar `\lt` o `\gt` en lugar de `<` y `>`.
4. **Contenido insertado después de cargar la página** (secciones que se muestran con JavaScript, tablas dinámicas, retroalimentación): ejecutar `MathJax.typesetPromise([contenedor])` después de insertarlo. Sin esto las fórmulas aparecen como texto plano.
5. Si las secciones se ocultan con `display:none`, MathJax igualmente las procesa al cargar; basta con llamar a `typesetPromise()` una vez al terminar la carga (`window.addEventListener('load', ...)`) y de nuevo para el contenido dinámico.
6. No colocar fórmulas dentro de elementos que se vuelvan a generar con `innerHTML` sin volver a llamar a `typesetPromise`.
7. Colores: heredan del texto; en tema oscuro basta con `mjx-container { color: inherit; }`.

---

# PARTE E. CONTENIDO DE REFERENCIA PARA LA EXPOSICIÓN (Valery · 5 minutos)

| Tiempo | Tema | Qué decir |
|---|---|---|
| 0:00–0:45 | Presentación del tema | «Muchas ecuaciones no se pueden despejar, como \(x^3-x-1=0\). Los métodos numéricos las resuelven por aproximación; hoy vemos uno que usa parábolas.» |
| 0:45–1:45 | Definición del método | Müller (1956); generaliza la secante; tres puntos, una parábola, una raíz de la parábola como nueva aproximación; sin derivadas; puede dar raíces complejas. |
| 1:45–2:45 | Fundamento | Tres puntos determinan una parábola (tres coeficientes). Forma centrada en \(x_2\): \(a(x-x_2)^2+b(x-x_2)+c\). Mostrar la ilustración del módulo 2. |
| 2:45–3:30 | Fórmulas | \(h_0,h_1,\delta_0,\delta_1,d,a,b,c,D\) y \(x_3=x_2-\frac{2c}{b\pm\sqrt D}\). Insistir: se elige el denominador de mayor magnitud para evitar cancelación. |
| 3:30–4:45 | Ejemplo resuelto | \(f=x^3-x-1\), (1, 1.5, 2). Mostrar la iteración 1 completa (x₃ = 1.3333) y la tabla: 4 iteraciones → 1.3247. |
| 4:45–5:00 | Cierre y enlace | «Ahora Danilo muestra cómo diseñamos la plataforma donde pueden practicar todo esto.» |

**Preguntas probables del público (con respuesta breve):**
- *¿Por qué no se usa Newton?* Necesita \(f'\), y Müller además da raíces complejas.
- *¿Siempre converge?* No; depende de los puntos iniciales.
- *¿Qué pasa si D es negativo?* Las raíces de la parábola son complejas; \(x_3\) será complejo y el método continúa.
- *¿Por qué el denominador de mayor magnitud?* Evita restar números casi iguales (pérdida de cifras) y escoge la raíz más cercana a \(x_2\).

---

# PARTE F. PAQUETE DE TRANSFERENCIA

**1. Entrega:** Valery
**2. Etapa completada:** Etapa 1 – Investigación y contenido académico

**3. Archivos creados**
| Archivo | Contenido |
|---|---|
| `01_investigacion_y_paquete_de_transferencia.md` | Investigación, verificación, MathJax, guion y este paquete |
| `02_modulos_aprende_muller.html` | Los cinco módulos listos para pegar en `index.html` (sección 2) |
| `03_contenido_juegos_desafios_evaluacion.json` | Contenido de los tres juegos, las cuatro misiones y las diez preguntas de la evaluación final |

**4. Código:** los archivos 02 y 03 son el código/contenido completo (no hay CSS ni JavaScript de Valery).

**5. Funcionalidades implementadas (contenido, no lógica):** cinco módulos con explicaciones, fórmulas, comparación, ejemplo resuelto con iteraciones reales, cinco preguntas de comprensión con retroalimentación; textos y respuestas de los juegos; cuatro misiones; diez preguntas de evaluación con explicaciones.

**6. Dependencias:** MathJax 3 (CDN). Para las clases del HTML: Bootstrap 5 y `styles.css` de Danilo.

**7. Instrucciones para ejecutar:** abrir `02_modulos_aprende_muller.html` solo muestra el contenido sin estilo; el fragmento debe insertarse en `index.html` y servirse con Live Server.

**8. Pruebas realizadas:** algoritmo ejecutado para las tres funciones del Juego 3, el ejemplo del módulo 5 y el caso \(x^2+1\); verificación algebraica de las fórmulas; validación de sintaxis del JSON.

**9. Errores conocidos / puntos abiertos**
- La referencia bibliográfica de Muller (1956) debe confirmarse con una fuente.
- Las ilustraciones de los módulos 1, 3, 4 y 5 están **especificadas** (bloques `<figure>` con descripción), no dibujadas; el módulo 2 incluye un SVG esquemático. Danilo las convierte en gráficos con el estilo visual.
- La interacción de las preguntas de comprensión (mostrar retroalimentación al elegir) no está programada: el contenido está en el HTML con `data-correcta`, `.retro-ok` y `.retro-error`. Decidir en equipo quién la conecta (sugerencia: Danilo la prepara visualmente y Said la conecta con `scoring.js`, sin puntuación, pues las preguntas de comprensión no otorgan puntos).

**10. Instrucciones para Danilo**
1. Insertar los cinco `<section class="modulo">` en la sección «Aprende Müller»; mostrar un módulo a la vez con navegación interna (Módulo 1 … 5).
2. Mantener los `id` (`modulo-1`…`modulo-5`, `m1-…`) por si el equipo necesita enlazarlos.
3. Aplicar las instrucciones MathJax de la Parte D.
4. Estilizar `.tabla-comparativa`, `.tabla-formulas`, `.tabla-iteraciones` (muy ancha: usar `.tabla-responsive` con scroll horizontal), `.ejemplo-numerico`, `.nota`, `.resultado-final`, `.retro-ok` (verde) y `.retro-error` (rojo).
5. Convertir las ilustraciones especificadas en gráficos coherentes con la identidad visual.
6. Para la sección de créditos y los espacios de juegos, el contenido está en el JSON (usarlo solo como referencia de textos; la lógica la implementa Said).
7. Convención común que no debe alterarse: error \(E=|x_3-x_2|\); denominador de mayor módulo; en empate se usa \(b+\sqrt D\).
